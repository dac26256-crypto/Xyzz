import React from 'react';
import axios from 'axios';

const App = () => {
  const handlePayment = async () => {
    const { data } = await axios.post(`${process.env.REACT_APP_API_URL}/create-order`, { amount: 50000 });
    const options = {
      key: process.env.REACT_APP_RAZORPAY_KEY_ID,
      amount: data.amount,
      currency: data.currency,
      name: "Demo Projects",
      description: "Test Transaction",
      order_id: data.id,
      handler: function (response) {
        alert("Payment Successful! Payment ID: " + response.razorpay_payment_id);
      },
      theme: { color: "#3399cc" },
    };
    const rzp = new window.Razorpay(options);
    rzp.open();
  };

  return (
    <div className="h-screen flex flex-col items-center justify-center bg-gray-100">
      <h1 className="text-3xl font-bold mb-6">Projects Demo</h1>
      <button
        onClick={handlePayment}
        className="bg-blue-500 text-white px-6 py-3 rounded-lg shadow-lg hover:bg-blue-600 transition"
      >
        Pay ₹500
      </button>
    </div>
  );
};

export default App;